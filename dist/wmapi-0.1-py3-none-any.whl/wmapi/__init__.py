"""pywalmart - Walmart Marketplace API"""

__version__ = '0.0.1'
__author__ = 'sellerzon.com <dev@sellerzon.com>'
__all__ = []

from .wmapi import *
